# Daily Dev Clone

Let's Build Daily Dev Clone using the future by using future-proof technology Laravel 11 as the backend and Next js 14 with typescript as the Front end.

In this video, we will also explore Reverb for real-time updates.

If you use this code then forget to give this star ⭐️⭐️
